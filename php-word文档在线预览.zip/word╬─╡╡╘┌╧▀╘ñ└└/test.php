    public function Resume_View()
    {
        if (!$uid=$this->global['user']['uid']) {
            header('Location: /user/login');
            exit();
        }
        if (!$id = filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT))
            $this->common->showmessage('��������','/job');
        $refile = $this->common->setCacheSingle("SELECT file,uid,cid,filetype FROM ".TNAME."job_recommend_resume WHERE rid={$id} LIMIT 1");
        $cid = $this->global['user']['company']['cid'];
        if ($refile['uid'] != $uid && $cid != $refile['cid'])
            $this->common->showmessage('��������','/job');

        if (!$file = $this->common->setCacheSingle("SELECT * FROM ".TNAME."file WHERE thumbdata='".$refile['file']."' LIMIT 1"))
            $this->common->showmessage('�ļ�������','/job');

        //�ļ�ת�� s
        $filetype = empty($refile['filetype'])? $file['format']: $refile['filetype'];
        $file_str = D_ROOT.$file['file'];
        $swf = '';
        $return_val = 1;
        if($filetype == 'swf'){
            $swf = D_ROOT.'files/swf/'.$file['hash'].'.swf';
        }
        if (function_exists('exec') && empty($swf) && file_exists($file_str)) {
            //pdf ת swf
            if($filetype == 'pdf'){
                $pdf = D_ROOT.$file['file'];
                $swf = D_ROOT.'files/swf/'.$file['hash'].'.swf';

                $command = '/opt/swftools/bin/pdf2swf -o '.$swf.' -T -z -t -f '.$pdf.' -s languagedir=/usr/local/share/xpdf/chinese-simplified -s flashversion=9 2>&1';

                exec($command, $output, $return_val);
                if($return_val == 0){//ִ�гɹ� ��ʾЧ��
                    $this->db->query("UPDATE ".TNAME."job_recommend_resume SET `filetype`='swf' WHERE rid={$id} ;");
                }

            }

            //doc or docx ת pdf ��ת swf
            if($filetype == 'doc' || $filetype == 'docx'){

                $doc = D_ROOT.$file['file'];
                $pdf = D_ROOT.'files/pdf/'.$file['hash'].'.pdf';
                $command = 'java -jar /opt/jodconverter/lib/jodconverter-cli-2.2.2.jar '.$doc.' '.$pdf.' 2>&1';
                exec($command, $output, $return_val);

                if($return_val == 0){//ִ�гɹ� ��ʾЧ��
                    $swf = D_ROOT.'files/swf/'.$file['hash'].'.swf';

                    $command = '/opt/swftools/bin/pdf2swf -o '.$swf.' -T -z -t -f '.$pdf.' -s languagedir=/usr/local/share/xpdf/chinese-simplified -s flashversion=9 2>&1';

                    exec($command, $output, $return_val);
                    if($return_val == 0){//ִ�гɹ� ��ʾЧ��
                        $this->db->query("UPDATE ".TNAME."job_recommend_resume SET `filetype`='swf' WHERE rid={$id} ;");
                    }
                }

            }

        }
        //�ļ�ת�� e

        if(!empty($swf) && file_exists($swf)){
            //����Ԥ������ swf
            $swf_link = W_DOMAIN .'/files/swf/'.$file['hash'].'.swf';
            $this->smarty->assign('swf_link', $swf_link);
            $this->smarty->display('test.tpl');
            exit;
        }else{
            $this->common->downFile($file['file'],$file['name']);
        }

    }